import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
  StyleSheet,
  SafeAreaView,
  Alert,
  Platform,
  StatusBar,
} from 'react-native';
import BottomNavBar from '../components/BottomNavBar';

const HomeScreen = ({ subjects = [] }) => {
  const handleSubjectClick = (subject) => {
    Alert.alert('과목 선택', `${subject.title}의 수행할 업무가 출력됩니다.`);
  };

  const handleRefresh = () => {
    Alert.alert('새로고침', '목록이 새로고침되었습니다.');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Schedule</Text>
          <TouchableOpacity style={styles.refreshButton} onPress={handleRefresh}>
            <Image source={require('../../assets/refresh.png')} style={styles.refreshIcon} />
          </TouchableOpacity>
        </View>

        <FlatList
          data={subjects}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => handleSubjectClick(item)}
              style={[styles.subjectCard, { backgroundColor: item.color }]}
            >
              <Text style={styles.subjectTitle}>{item.title}</Text>
              <Text style={styles.subjectDetails}>{item.details}</Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={styles.subjectList}
        />

        <BottomNavBar selectedTab="home" />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f7f9fc',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0, // 상태바 높이 고려
  },
  container: {
    flex: 1,
    paddingHorizontal: 16, // 좌우 여백 추가
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    paddingHorizontal: 16, // 좌우 여백 추가
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  refreshButton: {
    position: 'absolute',
    right: 16,
    padding: 8,
  },
  refreshIcon: {
    width: 24,
    height: 24,
  },
  subjectList: {
    paddingBottom: 80, // 네비게이션 바 공간 확보
  },
  subjectCard: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  subjectTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  subjectDetails: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
});

export default HomeScreen;
