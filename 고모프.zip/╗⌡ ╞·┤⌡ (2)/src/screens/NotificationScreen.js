import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  SafeAreaView,
  ScrollView,
  Image,
  Platform,
  StatusBar,
} from 'react-native';
import BottomNavBar from '../components/BottomNavBar';

const NotificationScreen = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedTime, setSelectedTime] = useState(null);

  const handleTimeSelect = (time) => {
    setSelectedTime(time);
    setModalVisible(false); // 모달 닫기
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* 상단 제목과 알람 설정 버튼 */}
        <View style={styles.header}>
          <Text style={styles.title}>알림 센터</Text>
          <TouchableOpacity
            style={styles.alarmButton}
            onPress={() => setModalVisible(true)}
          >
            <Image
              source={require('../../assets/set-alarm.png')}
              style={styles.alarmIcon}
            />
          </TouchableOpacity>
        </View>

        {/* 알림 항목 */}
        <ScrollView contentContainerStyle={styles.notificationList}>
          <View style={styles.notificationItem}>
            <Text style={styles.notificationText}>
              웹프레임워크1 영상 시청까지 5시간 남았습니다.
            </Text>
          </View>
          <View style={styles.notificationItem}>
            <Text style={styles.notificationText}>
              고급모바일프로그래밍 과제 제출까지 6시간 남았습니다.
            </Text>
          </View>
        </ScrollView>

        {/* 시간 설정 모달 */}
        <Modal visible={modalVisible} transparent={true}>
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>알림 시간 설정</Text>
              {['3시간 전', '6시간 전', '12시간 전', '1일 전', '3일 전'].map(
                (time) => (
                  <TouchableOpacity
                    key={time}
                    onPress={() => handleTimeSelect(time)}
                    style={styles.modalOption}
                  >
                    <Text style={styles.modalText}>{time}</Text>
                  </TouchableOpacity>
                )
              )}
              <TouchableOpacity
                onPress={() => setModalVisible(false)}
                style={styles.closeButton}
              >
                <Text style={styles.closeButtonText}>닫기</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* 기존 네비게이션 바 추가 */}
        <BottomNavBar selectedTab="alarm" />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0, // 상태바 높이 고려
  },
  container: {
    flex: 1,
    paddingHorizontal: 16, // 좌우 여백 설정 (홈 화면과 동일)
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  alarmButton: {
    position: 'absolute',
    right: 0,
    padding: 8,
  },
  alarmIcon: {
    width: 24,
    height: 24,
  },
  notificationList: {
    paddingBottom: 80, // 네비게이션 바 공간 확보
  },
  notificationItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  notificationText: {
    fontSize: 16,
    color: '#333',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '90%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalOption: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  modalText: {
    fontSize: 16,
    color: '#333',
  },
  closeButton: {
    marginTop: 16,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#1d4ed8',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default NotificationScreen;
