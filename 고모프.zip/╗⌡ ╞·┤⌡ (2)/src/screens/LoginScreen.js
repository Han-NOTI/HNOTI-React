import React from 'react';
import { View, TextInput, TouchableOpacity, Image, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const LoginScreen = () => {
  const navigation = useNavigation();

  const handleLogin = () => {
    // TODO: 백엔드와 연동 후 로그인 구현
    navigation.replace('HomeScreen');
  };

  return (
    <View style={styles.container}>
      {/* 로고 이미지 */}
      <Image 
        source={require('../../assets/logo.png')} // 로고 이미지 경로
        style={styles.logo} 
      />

      {/* 로그인 폼 */}
      <TextInput style={styles.input} placeholder="학번" />
      <TextInput style={styles.input} placeholder="비밀번호" secureTextEntry />
      <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
        <Text style={styles.loginText}>로그인</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f7f9fc',
  },
  logo: {
    width: 150, // 로고 이미지 너비
    height: 150, // 로고 이미지 높이
    marginBottom: 20, // 아래 여백
    resizeMode: 'contain', // 로고 이미지 비율 유지
  },
  input: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 15,
    backgroundColor: '#fff',
  },
  loginButton: {
    width: '80%',
    height: 45,
    backgroundColor: '#1d4ed8',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },
  loginText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default LoginScreen;
