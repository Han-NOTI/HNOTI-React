import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const SplashScreen = ({ onLoaded }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onLoaded();
    }, 3000); // 3초 후 호출
    return () => clearTimeout(timer);
  }, [onLoaded]);

  return (
    <View style={styles.container}>
      <Image source={require('../../assets/bell.png')} style={styles.logo} />
      <Text style={styles.title}>한성 NOTI</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f7f9fc',
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1d4ed8',
  },
});

export default SplashScreen;
