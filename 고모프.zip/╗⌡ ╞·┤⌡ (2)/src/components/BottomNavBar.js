import React from 'react';
import { View, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const BottomNavBar = ({ selectedTab }) => {
  const navigation = useNavigation();

  const handleTabPress = (tab) => {
    if (tab === 'home') {
      navigation.navigate('HomeScreen');
    } else if (tab === 'alarm') {
      navigation.navigate('NotificationScreen');
    } else if (tab === 'profile') {
      navigation.navigate('ProfileScreen');
    }
  };

  return (
    <View style={styles.navContainer}>
      <View style={styles.navigationBar}>
        {/* 홈 버튼 */}
        <TouchableOpacity
          onPress={() => handleTabPress('home')}
          style={styles.navButton}
        >
          <Image
            source={
              selectedTab === 'home'
                ? require('../../assets/home2.png') // 선택된 상태 (파란색)
                : require('../../assets/home1.png') // 비선택 상태 (회색)
            }
            style={styles.navIcon}
          />
        </TouchableOpacity>

        {/* 알림 버튼 */}
        <TouchableOpacity
          onPress={() => handleTabPress('alarm')}
          style={styles.navButton}
        >
          <Image
            source={
              selectedTab === 'alarm'
                ? require('../../assets/noti2.png') // 선택된 상태 (파란색)
                : require('../../assets/noti1.png') // 비선택 상태 (회색)
            }
            style={styles.navIcon}
          />
        </TouchableOpacity>

        {/* 프로필 버튼 */}
        <TouchableOpacity
          onPress={() => handleTabPress('profile')}
          style={styles.navButton}
        >
          <Image
            source={
              selectedTab === 'profile'
                ? require('../../assets/profile2.png') // 선택된 상태 (파란색)
                : require('../../assets/profile1.png') // 비선택 상태 (회색)
            }
            style={styles.navIcon}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  navContainer: {
    backgroundColor: '#f7f9fc',
    alignItems: 'center',
    paddingVertical: 0, // 패딩 제거
    paddingBottom: 10, // 하단만 패딩 추가
  },
  navigationBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 50, // 높이를 줄여서 확인
    width: '100%', // 부모 너비에 맞춤
    backgroundColor: '#fff',
    borderRadius: 30,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },
  
  navButton: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  navIcon: {
    width: 24, // 적절한 크기로 설정
    height: 24,
    resizeMode: 'contain', // 이미지가 왜곡되지 않도록
  },
  
});

export default BottomNavBar;
